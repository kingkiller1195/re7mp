local CFG = {
    RELEASE = "0.6",
    BUILD = "9.45",
}
