local CFG = {
    RELEASE = "0.5",
    BUILD = "9.44",
}
